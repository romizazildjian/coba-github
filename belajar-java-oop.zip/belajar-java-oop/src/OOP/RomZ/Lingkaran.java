package OOP.RomZ;

public class Lingkaran {
//    final double phi = 3.14;
//    double diameter, tinggi, luas, volume;
//
//    double hitungluas(float diameter){
//        luas = phi / 4 * (diameter * diameter);
//        return luas;
//    }
//
//    double hitungvolume (double diameter){
//
//    }
}
