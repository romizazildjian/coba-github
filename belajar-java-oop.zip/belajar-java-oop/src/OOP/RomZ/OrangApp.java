package OOP.RomZ;

public class OrangApp {
}
