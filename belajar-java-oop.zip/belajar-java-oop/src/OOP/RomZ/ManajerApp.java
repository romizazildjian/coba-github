package OOP.RomZ;

// INHERITANCE

public class ManajerApp {
    public static void main(String[] args) {

        var manajer = new Manajer("Endro");
//        manajer.name= "Endro";
        manajer.sayHello("Mamad");

        var vice = new Vice("lisa");
//        vice.name= "Lisa";
        vice.sayHello("Lupa");
    }
}
