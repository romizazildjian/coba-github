package OOP.RomZ;

public class Shape {
    int getCorner(){
        return 0;
    }
}


class Rec extends Shape{
   int getCorner(){
       return 4;
   }

   int getParrent (){
       return super.getCorner();
   }
}


