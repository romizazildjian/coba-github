package OOP.RomZ;

import java.awt.image.DataBufferUShort;

class Person {
    String name;
    int age;
    final String country = "Bali - Indonesia";

    Person(String name, int age){
        this.name = name;
        this.age = age;

//        ATAU


    }

    Person(String name){
        this.name = name;
//
//        ATAU --> Panggil constructor

//        this("Eko");


    }

    Person(){

    }

    void sayHi (String name) {
        System.out.println("Halo "+name+"saya "+this.name);
    }
    void sayHello (String parName){
        System.out.println("Hallo "+parName+" nama saya "+name);
    }
}
