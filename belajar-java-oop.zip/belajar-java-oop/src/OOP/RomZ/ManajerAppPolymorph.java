package OOP.RomZ;

public class ManajerAppPolymorph {
    public static void main(String[] args) {
        Employ employ = new Employ("Romi");
        employ.sayHello("Yan Adi");

        employ = new Vice("Adrian");
        employ.sayHello("Dyah");

        employ = new Manajer("Michael");
        employ.sayHello("Aldo");

        System.out.println();
        System.out.println();

        sayHello(new Employ("Nafis"));
        sayHello(new Manajer("Ganda"));
        sayHello(new Vice("Astuti"));
    }

    static void sayHello(Employ employ){
        System.out.println("Helo "+employ.name);
    }
}
