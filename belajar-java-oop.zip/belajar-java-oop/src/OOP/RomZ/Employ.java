package OOP.RomZ;

public class Employ {
    String name;

    Employ(String name){
        this.name = name;
    }
    void sayHello (String name){

        System.out.println("Hello "+name+" My name is employee "+this.name);
    }
}
