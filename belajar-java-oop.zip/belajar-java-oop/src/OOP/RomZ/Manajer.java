package OOP.RomZ;

class Manajer extends Employ {
//    String name;  //sekarang di extend ke employ maka ini di hapus

    Manajer(String name){
//        this.name = name;//
        super(name);
    }

    void sayHello (String name){

        System.out.println("Hello "+name+" My name is manajer "+this.name);
    }
}

class Vice extends Manajer{

    //Using super constructor
    Vice(String name){
        super(name);
    }
    // Overiding (method di panggil sesuai scope, sehingga yang ada di manajer tidak di baca
    void sayHello (String name){
        System.out.println("Hello "+name+" My name is vice president "+this.name);
    }
}

// Dengan pewarisan (inheritence) -- Kata kunci extend -- kita tidak perlu mengetik ulang yang ada di kelas manajer
