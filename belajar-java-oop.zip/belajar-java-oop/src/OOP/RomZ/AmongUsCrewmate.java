package OOP.RomZ;

public class AmongUsCrewmate extends AmongUs{
    int jumlahTask;

    AmongUsCrewmate(){
        super.role = "Role  : Crewmate";
    }

    public void setJumlahTask(int jumlahTask) {
        this.jumlahTask = jumlahTask;
    }

    public int getJumlahTask() {
        return jumlahTask;
    }

    void finishTask(){
        if(getJumlahTask()==10){
            System.out.println("Tsk selese");
        }else{
            System.out.println("Task belom selese, tersisa"+ (10 - getJumlahTask()) );
        }
    }

    //    AmongUsCrewmate(){
//
//    }
}
