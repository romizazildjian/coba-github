package OOP.RomZ;

public class ShapeApp {
    public static void main(String[] args) {
        var shape = new  Shape();
        System.out.println(shape.getCorner());

        var rec = new Rec();
        System.out.println(rec.getCorner());
        System.out.println(rec.getParrent()+"--> Ini dari super keyword");
    }
}


