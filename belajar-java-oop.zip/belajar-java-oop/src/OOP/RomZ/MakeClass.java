package OOP.RomZ;

public class MakeClass {
}
