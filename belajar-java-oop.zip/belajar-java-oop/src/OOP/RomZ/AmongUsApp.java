package OOP.RomZ;

public class AmongUsApp {
    private static Object AmongUs;

    public static void main(String[] args) {
        var amongUsCrewmate1 = new AmongUsCrewmate();
        amongUsCrewmate1.setNama("Romiza");
        amongUsCrewmate1.setWarna("Biru");
        amongUsCrewmate1.setJumlahTask(10);

        amongUsCrewmate1.siapaAku();
        amongUsCrewmate1.finishTask();

        AmongUsImpostor amongUsImpostor1 = new AmongUsImpostor();
        amongUsImpostor1.setNama("Adrian");
        amongUsImpostor1.setWarna("Merah");
        amongUsImpostor1.setKill(7);

        amongUsImpostor1.siapaAku();
        amongUsImpostor1.totalKill();

        var amongUsImpostor2 = new  AmongUsImpostor();
        amongUsImpostor2.setNama("Google");
        amongUsImpostor2.setWarna("Pimk");
        amongUsImpostor2.setKill(0);

        amongUsImpostor2.siapaAku();
        amongUsImpostor2.totalKill();




//        System.out.println();
    }
}
