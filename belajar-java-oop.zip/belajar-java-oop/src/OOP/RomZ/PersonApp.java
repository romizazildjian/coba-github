package OOP.RomZ;

public class PersonApp {
    public static void main(String[] args) {
//        cara 1
        var person1 = new Person("Reza Octavian", -11);

        System.out.println(person1.name);
        System.out.println(person1.age);
        System.out.println(person1.country);

        System.out.println("_________________________");
        System.out.println("_________________________");
        System.out.println("_________________________");

//        cara 2
        Person person2 = new Person();

        System.out.println(person2.name);
        System.out.println(person2.age);
        System.out.println(person2.country);
        System.out.println("_________________________");

        person2.sayHello("Dyah Kencana Dewi");
        System.out.println("_________________________");
//        cara 3
        Person person3;
        person3 = new Person();

        person3.name="Rizky Aditya Ichwanto";
        person3.age=19;

        System.out.println(person3.name);
        System.out.println(person3.age);
        System.out.println(person3.country);
        System.out.println("_________________________");

        person2.sayHello("Putri Nabila");
        System.out.println("_________________________");

//        System.out.println(person1);
//        System.out.println(person2);
//        System.out.println(person3);
    }
}
