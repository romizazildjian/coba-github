package OOP.RomZ;

// getter mengambil & setter mengubah nilai

// AmongUs
// -- CM
// -- IM

public class AmongUs {
    String warna, nama, role;

    public String getRole() {
        return role;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNama() {
        return nama;
    }

    public void setWarna(String parWarna){
        warna = parWarna;
    }

    public String getWarna(){
        return warna;
    }



    void siapaAku(){

        System.out.println(getNama());
        System.out.println(getWarna());
        System.out.println(getRole());
        System.out.println("== == == == == == ==");
    }
}
