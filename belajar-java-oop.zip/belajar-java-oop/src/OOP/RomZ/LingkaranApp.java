package OOP.RomZ;

public class LingkaranApp {
    public static void main(String[] args) {



    }
}
