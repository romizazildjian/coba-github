package OOP.RomZ;

public class AmongUsImpostor extends AmongUs {
    int kill;

    AmongUsImpostor(){super.role= "Role: Impostor";}

    public void setKill(int kill) {
        this.kill = kill;
    }

    public int getKill() {
        return kill;
    }

    void totalKill(){
        if (getKill()==7){
            System.out.println("Impostor win");
        }else if(getKill()<=7 && getKill()>=0){
            System.out.println("Baru kill"+getKill());
        }else {
            System.out.println("Error! kill hanya dari 0-7 saja");
        }
    }
}
